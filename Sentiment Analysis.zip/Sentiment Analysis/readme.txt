This program uses the following libraries:
    tkinter, 
    textblob,
    wikipedia api,
    nltk
The textblob and nltk are used primarily for the sentiment Analysis.
I obviously used tkinter for my UI and used the wikipedia api for 
pulling the subject information.

The program works by having the user enter in 2 subjects and then we 
pull and obtain the polarity to determine which ahs a more positive
rating. We then output this info to the user. 